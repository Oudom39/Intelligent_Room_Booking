import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../../../shared/themes/app_theme.dart';
import '../providers/booking_provider.dart';

class BookingFormScreen extends StatefulWidget {
  final RoomModel room;
  const BookingFormScreen({super.key, required this.room});

  @override
  State<BookingFormScreen> createState() => _BookingFormScreenState();
}

class _BookingFormScreenState extends State<BookingFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _purposeCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  int _attendees = 1;
  DateTime _selectedDate = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _startTime = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _endTime = const TimeOfDay(hour: 10, minute: 0);
  bool _isSubmitting = false;
  String? _availabilityMessage;
  bool? _isAvailable;

  String get _dateStr => DateFormat('yyyy-MM-dd').format(_selectedDate);
  String get _startStr =>
      '${_startTime.hour.toString().padLeft(2, '0')}:${_startTime.minute.toString().padLeft(2, '0')}';
  String get _endStr =>
      '${_endTime.hour.toString().padLeft(2, '0')}:${_endTime.minute.toString().padLeft(2, '0')}';

  Future<void> _pickDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 14)),
    );
    if (date != null) {
      setState(() {
        _selectedDate = date;
        _isAvailable = null;
      });
    }
  }

  Future<void> _pickTime(bool isStart) async {
    final time = await showTimePicker(
      context: context,
      initialTime: isStart ? _startTime : _endTime,
    );
    if (time != null) {
      setState(() {
        if (isStart) {
          _startTime = time;
        } else {
          _endTime = time;
        }
        _isAvailable = null;
      });
    }
  }

  Future<void> _checkAvailability() async {
    final result = await context.read<BookingProvider>().checkAvailability(
          roomId: widget.room.id,
          date: _dateStr,
          startTime: _startStr,
          endTime: _endStr,
        );
    setState(() {
      _isAvailable = result['available'];
      _availabilityMessage = result['available'] == true
          ? 'Room is available for this time slot!'
          : 'Room is not available. Please choose a different time.';
    });
  }

  Future<void> _submitBooking() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSubmitting = true);

    final result = await context.read<BookingProvider>().createBooking(
          roomId: widget.room.id,
          date: _dateStr,
          startTime: _startStr,
          endTime: _endStr,
          purpose: _purposeCtrl.text.trim(),
          attendees: _attendees,
          notes: _notesCtrl.text.trim(),
        );

    setState(() => _isSubmitting = false);
    if (!mounted) return;

    if (result['success'] == true) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Row(
            children: [
              Icon(Icons.check_circle_rounded,
                  color: AppTheme.success, size: 28),
              SizedBox(width: 8),
              Text('Booking Confirmed!'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Room: ${widget.room.name}'),
              Text('Date: $_dateStr'),
              Text('Time: $_startStr - $_endStr'),
              Text('Purpose: ${_purposeCtrl.text}'),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: const Text('Great!'),
            ),
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(result['error'] ?? 'Booking failed'),
          backgroundColor: AppTheme.danger,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Book a Room')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Room info header
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: AppTheme.primaryGradient,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  const Icon(Icons.meeting_room_rounded,
                      color: Colors.white, size: 36),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.room.name,
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16)),
                        Text(
                            '${widget.room.roomNumber} • Capacity: ${widget.room.capacity}',
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 13)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Date picker
            const Text('Select Date',
                style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            InkWell(
              onTap: _pickDate,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  border: Border.all(color: AppTheme.border),
                  borderRadius: BorderRadius.circular(12),
                  color: AppTheme.surface,
                ),
                child: Row(
                  children: [
                    const Icon(Icons.calendar_today_rounded,
                        color: AppTheme.primary),
                    const SizedBox(width: 12),
                    Text(DateFormat('EEEE, dd MMM yyyy').format(_selectedDate),
                        style: const TextStyle(fontSize: 15)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Time pickers
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Start Time',
                          style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      InkWell(
                        onTap: () => _pickTime(true),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 14),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppTheme.border),
                            borderRadius: BorderRadius.circular(12),
                            color: AppTheme.surface,
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.access_time_rounded,
                                  color: AppTheme.primary, size: 18),
                              const SizedBox(width: 8),
                              Text(_startStr,
                                  style: const TextStyle(fontSize: 15)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('End Time',
                          style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      InkWell(
                        onTap: () => _pickTime(false),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 14),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppTheme.border),
                            borderRadius: BorderRadius.circular(12),
                            color: AppTheme.surface,
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.access_time_filled_rounded,
                                  color: AppTheme.primary, size: 18),
                              const SizedBox(width: 8),
                              Text(_endStr,
                                  style: const TextStyle(fontSize: 15)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Check availability button
            OutlinedButton.icon(
              icon: const Icon(Icons.search_rounded),
              label: const Text('Check Availability'),
              onPressed: _checkAvailability,
            ),

            if (_availabilityMessage != null) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: (_isAvailable == true
                          ? AppTheme.success
                          : AppTheme.danger)
                      .withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Icon(
                      _isAvailable == true
                          ? Icons.check_circle_outline
                          : Icons.error_outline,
                      color: _isAvailable == true
                          ? AppTheme.success
                          : AppTheme.danger,
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(_availabilityMessage!,
                          style: TextStyle(
                            color: _isAvailable == true
                                ? AppTheme.success
                                : AppTheme.danger,
                          )),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 16),

            // Attendees
            const Text('Number of Attendees',
                style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Row(
              children: [
                IconButton(
                  onPressed:
                      _attendees > 1 ? () => setState(() => _attendees--) : null,
                  icon: const Icon(Icons.remove_circle_outline_rounded),
                  color: AppTheme.primary,
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppTheme.border),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text('$_attendees',
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w600)),
                ),
                IconButton(
                  onPressed: _attendees < widget.room.capacity
                      ? () => setState(() => _attendees++)
                      : null,
                  icon: const Icon(Icons.add_circle_outline_rounded),
                  color: AppTheme.primary,
                ),
                Text('/ ${widget.room.capacity} max',
                    style: const TextStyle(color: AppTheme.textMuted)),
              ],
            ),
            const SizedBox(height: 16),

            // Purpose
            TextFormField(
              controller: _purposeCtrl,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Purpose of Booking',
                hintText: 'e.g. Team meeting, Study session...',
                prefixIcon: Icon(Icons.note_alt_outlined),
              ),
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'Purpose is required' : null,
            ),
            const SizedBox(height: 16),

            // Notes (optional)
            TextFormField(
              controller: _notesCtrl,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Additional Notes (optional)',
                prefixIcon: Icon(Icons.comment_outlined),
              ),
            ),
            const SizedBox(height: 24),

            // Submit button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: _isSubmitting
                    ? const SizedBox(
                        height: 18,
                        width: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.event_available_rounded),
                label: Text(_isSubmitting ? 'Booking...' : 'Confirm Booking'),
                onPressed: _isSubmitting ? null : _submitBooking,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
