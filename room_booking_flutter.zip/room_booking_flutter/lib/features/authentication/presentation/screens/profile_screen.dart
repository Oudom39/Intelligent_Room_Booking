import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../shared/themes/app_theme.dart';
import '../../../authentication/presentation/providers/auth_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
        actions: [
          TextButton.icon(
            icon: const Icon(Icons.logout_rounded, size: 18),
            label: const Text('Logout'),
            onPressed: () async {
              await context.read<AuthProvider>().logout();
              if (context.mounted) {
                Navigator.pushReplacementNamed(context, '/login');
              }
            },
            style: TextButton.styleFrom(foregroundColor: AppTheme.danger),
          ),
        ],
      ),
      body: user == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // Avatar
                Center(
                  child: Stack(
                    children: [
                      Container(
                        width: 100,
                        height: 100,
                        decoration: const BoxDecoration(
                          gradient: AppTheme.heroGradient,
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text(
                            (user.firstName.isNotEmpty)
                                ? user.firstName[0].toUpperCase()
                                : 'U',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 40,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Center(
                  child: Text(
                    user.fullName.isNotEmpty ? user.fullName : user.email,
                    style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.textPrimary),
                  ),
                ),
                const SizedBox(height: 4),
                Center(
                  child: Text(
                    user.email,
                    style: const TextStyle(
                        color: AppTheme.textSecondary, fontSize: 14),
                  ),
                ),
                if (user.isAdmin)
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.only(top: 6),
                      child: Chip(
                        label: Text('Admin',
                            style: TextStyle(
                                color: AppTheme.primary,
                                fontWeight: FontWeight.bold,
                                fontSize: 12)),
                        backgroundColor: Color(0xFFEFF6FF),
                        side: BorderSide(color: AppTheme.primary, width: 0.5),
                      ),
                    ),
                  ),
                const SizedBox(height: 24),

                // Info card
                Card(
                  child: Column(
                    children: [
                      _InfoRow(
                        icon: Icons.badge_outlined,
                        label: 'Student ID',
                        value: user.studentId.isNotEmpty
                            ? user.studentId
                            : 'Not set',
                      ),
                      const Divider(height: 1, indent: 56),
                      _InfoRow(
                        icon: Icons.phone_outlined,
                        label: 'Phone',
                        value: user.phoneNumber.isNotEmpty
                            ? user.phoneNumber
                            : 'Not set',
                      ),
                      const Divider(height: 1, indent: 56),
                      _InfoRow(
                        icon: Icons.school_outlined,
                        label: 'Faculty',
                        value: user.faculty.isNotEmpty
                            ? user.faculty
                            : 'Not set',
                      ),
                      const Divider(height: 1, indent: 56),
                      _InfoRow(
                        icon: Icons.apartment_outlined,
                        label: 'Department',
                        value: user.department.isNotEmpty
                            ? user.department
                            : 'Not set',
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoRow(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Icon(icon, color: AppTheme.primary, size: 20),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        fontSize: 11, color: AppTheme.textMuted)),
                const SizedBox(height: 2),
                Text(value,
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: AppTheme.textPrimary)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
