#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\ROG Zephyrus G15\Downloads\flutter_windows_3.41.4-stable\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\ROG Zephyrus G15\Desktop\Intelligent_Room_Booking\room_booking_flutter"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
